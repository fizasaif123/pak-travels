﻿using System;
namespace TravelRecordApp.Helpers
{
    public class Constants
    {
        public const string VENUE_SEARCH = "https://api.foursquare.com/v2/venues/search?ll={0},{1}&client_id={2}&client_secret={3}&v={4}";
        public const string CLIENT_ID = "CZPYHQC5IXEWAQ2SLCOYMZII11DVHXOPAZKDVQAC1M1YWISC";
        public const string CLIENT_SECRET = "1QWSOQQLNVNWEVTFK0XFDEI5GFCNM5KIDO4VXXZC5DSCW4MC";
    }
}
